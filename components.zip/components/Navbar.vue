<template>
    <nav class="navbar">
        <router-link to="/"> <i class="fas fa-user"></i> <span>profile</span> </router-link>
        <router-link to="/about"> <i class="fas fa-address-card"></i> <span>about</span> </router-link>
        <router-link to="/projects"> <i class="fas fa-briefcase"></i> <span>projects</span> </router-link>
        <router-link to="/contact"> <i class="fas fa-address-book"></i> <span>contact</span> </router-link>
    </nav>
</template>

<script>
export default {

}
</script>

<style>

</style>